import MyIcons from '@/components/UI/MyIcons'
import MySwitch from '@/components/UI/MySwitch'
import MyFilter from '@/components/UI/MyFilter'
//import MySpinner from '@/components/UI/MySpinner'


export default [
    MyIcons,
    MySwitch,
    MyFilter,
    //MySpinner
];