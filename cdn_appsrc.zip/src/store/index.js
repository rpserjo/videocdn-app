import { createStore } from 'vuex'

export default createStore({
  state: {
    showSpinner : false,
    showPlayer : false,
    playerVideoSrc : '',
    watchOnline : (window.localStorage.getItem("watchOnline") == 'true') ? true : false,
    api : {
      protocol : 'https:',
      host : '//3.svetacdn.in',
      token : 'gZrhCKFj6pA1W4h96i6g5IjhW7aR0CLk'
    },
    translations : {},
    searchResults : {},    
    current : {layout: 'indexLayout', type: '', id: -1, translation_id : -1, season_key : -1, episode_key : -1, quality : -1},
    labels : {movie: 'Кино', tv_series: 'Сериал', show_tv_series: 'ТВ'},
    mediaDialog : {
      show : false,
      absolute : false,
      position : {x: -1000, y: -1000},
      title : '',
      sources : {}
    },
    isMobile : (window.innerWidth < 500 || window.innerHeight < 900) ? true : false,
    watchHistory : []
  },
  getters: {
    getSortedList : (state) => {
      return Object.values(state.searchResults).sort((a, b) => {
        return a.ru_title < b.ru_title ? -1 : a.ru_title > b.ru_title ? 1 : 0
      })
    },
    getCurrent : (state) => {
      return state.current
    },
    getMediaInfo : (state) => (key) => {
      return (state.searchResults[state.current.id][key] != undefined) ? state.searchResults[state.current.id][key] : null
    },
    getTranslations : (state) => {
      return (state.searchResults[state.current.id].translations != undefined) ? state.searchResults[state.current.id].translations : null
    }
  },
  mutations: {
    setSpinner : (state, spinnerState = false) => {
      state.showSpinner = spinnerState
    },
    navigateTo : (state, target) => {
      state.current.layout = target
    },
    setTranslations : (state, translations) => {
      translations.data.forEach((translation) => {
        state.translations[translation.id] = translation.short_title
      })
    },
    appendElement : (state, {id, element}) => {
      state.searchResults[id] = element
    },
    resetCurrent : (state) => {
      state.current = {
        layout: 'indexLayout', 
        type: null, 
        id: null, 
        translation_id : -1, 
        season_key : -1, 
        episode_key : -1, 
        quality : -1
      }
    },
    setCurrent : (state, payload) => {
      for(let key of Object.keys(payload)){
        state.current[key] = payload[key]
      }
    },
    resetSearchResults : (state) =>{
      state.searchResults = {}
    },
    closeMediaDialog : (state) => {
      state.mediaDialog = {show : false, position: {x : -1000, y: -1000}, sources: {}}
    },
    setCurrentEpisode : (state, episode_key) => {
      state.current.episode_key = episode_key
    },
    closePlayer : (state) => {
      state.showPlayer = false
      state.playerVideoSrc = ''
    },
    showMediaDialog : (state, {title, position, sources}) => {
      state.mediaDialog = {show: true, absolute: !state.isMobile, position: position, title: title, sources: sources}
    }
  },
  actions: {
    prepareUrl ({state, getters}, {type, searchQuery, yearFilter}){
      let url
      switch(type){
        case 'movies':
          url = '/api/movies?query=' + searchQuery + '&limit=100'
          break
        case 'tv-series':
          url = '/api/tv-series?query=' + searchQuery + '&limit=100'
          break
        case 'show-tv-series':
          url = '/api/show-tv-series?query=' + searchQuery + '&limit=100'
          break
        case 'translations':
          url = '/api/translations?'
          break
      }
      return state.api.protocol + state.api.host + url + (Number(yearFilter) > 0 ? '&year=' + Number(yearFilter) : '') + '&api_token=' + state.api.token
    },
    async updateTranslations ({state, commit, dispatch}) {
      const url = await dispatch('prepareUrl', {type: 'translations'})
      try{
        commit('setSpinner', true)
        const response = await fetch(url)
        if(response.ok){
          let translations = await response.json()
          commit('setTranslations', translations)
        }else{
          throw new Error(response.status)
        }
      }catch(e){
        console.log(e)
      }finally{
        commit('setSpinner', false)
      }
    },
    async search({state, commit, dispatch}, {types, searchQuery, yearFilter}){
      for(let type of types){
        let url = await dispatch('prepareUrl', {type: type, searchQuery: searchQuery, yearFilter: yearFilter})
        state.showSpinner = true
        try{
          const response = await fetch(url)
          if(response.ok){
            const json = await response.json()
            dispatch('processResponse', {response: json})
          }else{
            throw new Error(response.status)
          }
        }catch(e){
          console.log(url, e)
        }finally{
          state.showSpinner = false              
        }
      }
      if(Object.keys(state.searchResults).length == 0){
        commit('resetCurrent', {id: 0, type: '', view: 'noResultsComponent'})
      }
    },
    processResponse({state, commit, dispatch}, {response}){
      if(response.data.length > 0){
        response.data.forEach((media) => {
          const id = media.content_type + '_' + media.id
          let element = {
            id: id,
            orig_title: media.orig_title,
            seasons: (media.season_count != undefined) ? media.season_count : 0,
            translations: {},
            src: state.api.protocol + media.iframe_src,
            episodes_info: {},
            type: (media.content_type == 'movie') ? 'movie' : 'tv',
            label: (state.labels[media.content_type] != undefined) ? state.labels[media.content_type] : '???',
            ru_title: media.ru_title,
            released: (media.content_type == 'movie') ? media.released.substring(0,4) : media.start_date.substring(0, 4),
            kinopoisk_id: media.kinopoisk_id,
            avatar: state.api.protocol + '//st.kp.yandex.net/images/film_big/' + media.kinopoisk_id + '.jpg'
          }
          if(media.episodes != undefined){
            let episodes_info = {}
            media.episodes.forEach((episode) => {
              let episode_key = episode.season_num + '_' + Number(episode.num)
              episodes_info[episode_key] = {
                season: episode.season_num, 
                num: episode.num, 
                orig_title: episode.orig_title, 
                ru_title: episode.ru_title
              }
            })
            element.episodes_info = episodes_info
          }
          commit('appendElement', {id: id, element: element})              
        })
      }
    },
    async loadMedia({state, commit, dispatch}, {id}){
      const layout = (state.searchResults[id].type == 'movie') ? 'detailsMovieLayout' : 'detailsTvLayout'
      commit('resetCurrent')
      commit('navigateTo', layout)
      commit('setCurrent', {id: id})
      let url = state.searchResults[id].src
      //state.showSpinner = true
      commit('setSpinner', true)
      try{
        const response = await fetch(url)
        if(response.ok){
          let data = await response.text()
          if(data.length > 0){
            data = await dispatch('prepareHTML', {html: data})
            if(data.keys != undefined && data.data != undefined){
              data.keys.forEach(async (key) => {
                if(key > 0){
                  if(data.type == 'movie'){
                    state.searchResults[id].translations[key] = {
                      translation_id: key, 
                      translation_title: state.translations[key], 
                      links: await dispatch('getHrefs', {files: data.data[key]})
                    }                        
                  }else{
                    state.searchResults[id].translations[key] = {
                      translation_id: key, 
                      translation_title: state.translations[key], 
                      episodes: [], 
                      seasons: []
                    }
                    let variant = JSON.parse(data.data[key])
                    variant.forEach(async (v) => {
                      if(v.hasOwnProperty('folder')){
                        var season = {
                          season_title: v.comment, 
                          episodes: []
                        }
                        v.folder.forEach(async (episode) => {
                          let title = episode.comment.split('&lt;br&gt;&lt;i&gt;')[0]
                          if(state.searchResults[id].episodes_info[episode.id] != undefined){
                            let info = state.searchResults[id].episodes_info[episode.id]
                            let _title = (info.orig_title.toLowerCase() == info.ru_title.toLowerCase()) ? info.orig_title : info.orig_title + " / " + info.ru_title
                            title = info.season + "." + info.num + " " + _title
                          }
                          season.episodes.push({
                            episode_title: title, 
                            links: await dispatch('getHrefs', {files: episode.file})
                          })
                        })
                        state.searchResults[id].translations[key].seasons.push(season)
                      }else{
                        state.searchResults[id].translations[key].episodes.push({
                          episode_title: v.comment.split('&lt;br&gt;&lt;i&gt;')[0], 
                          links: await dispatch('getHrefs', {files: v.file})
                        })
                      }
                    })
                  }
                }
              })
            }
          }else{
            console.log('zero data')
          }
        }else{
          console.log('data not loaded')
        }
      }catch(e){
        console.log(e)
      }finally{
        //state.showSpinner = false
        commit('setSpinner', false)
      }
    },
    prepareHTML ({state}, {html}){
      let userkey = html.match('var userKey = "(.*)";')
      let type = html.match('id="videoType" value="(.*)"')
      let files = html.match('id="files" value="(.*)"')
      files = files[1].split(userkey[1]).join('')
      files = files.split('&quot;').join('"')
      let data = JSON.parse(files)
      let keys = Object.keys(data)
      return {'type': type[1], 'data': JSON.parse(files), 'keys': Object.keys(data)}
    },
    getHrefs ({state}, {files: files}){
      let url_base
      let qualities = []
      let links = files.split(',');
      links = links[links.length-1].substring(7).split(' or ');
      for(let i = 0; i < links.length; i++){
        let tmp = links[i].split('/');
        if(qualities.indexOf(tmp[tmp.length-1].split('.mp4').join('')) < 0) qualities.push(tmp[tmp.length-1].split('.mp4').join(''))
        url_base = tmp.slice(0, -1).join('/')
      }
      return {qualities: qualities.sort(), link_base: state.api.protocol + url_base}
    },
  },
  
  modules: {
  }
})
