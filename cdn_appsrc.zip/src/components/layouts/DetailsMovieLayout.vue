<template>
    <div class="media-card">
        <media-card />
        <div 
            v-for="(translation) in getTranslations" 
            :key="translation.translation_id" 
            class="media-element">
            {{translation}}
        <!--<links :translation="translation"/>-->
        </div>
    </div>
</template>

<script>
import MediaCard from '@/components/MediaCardComponent'
import { mapGetters } from 'vuex'
export default {
    name : 'detailsMovieLayout',
    components: {MediaCard},
    computed: {
        ...mapGetters(['getTranslations'])
    }
}
</script>

<style scoped>
    .media-element{
        border-bottom: 1px solid var(--color-gray);
        padding: 3px 5px;
        margin-top: -1px;
    }
</style>