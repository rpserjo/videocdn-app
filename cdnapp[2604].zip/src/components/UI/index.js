import MyIcon from '@/components/UI/MyIcon'
import MySwitch from '@/components/UI/MySwitch'
import MyFilter from '@/components/UI/MyFilter'
//import MySpinner from '@/components/UI/MySpinner'


export default [
    MyIcon,
    MySwitch,
    MyFilter,
    //MySpinner
];