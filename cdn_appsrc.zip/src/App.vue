<template>
  <Spinner/>
  <Header 
    v-model:searchQuery="searchQuery" 
    v-model:showTunes="showTunes" 
    :windowWidth="windowWidth"
    @search="search"
  />
  <Tunes 
    v-model:showTunes="showTunes" 
    v-model:searchTypes="searchTypes" 
    v-model:yearFilter="yearFilter"
    @search="search"  
  />
  <div class="content">        
    <div class="wrap">
      <transition name="component-fade" mode="out-in" @before-enter="scrollToTop">
        <component 
          :is="getCurrent.layout"
          :sorted-list="getSortedList" 
        ></component>
      </transition>
    </div>
  </div>
</template>

<script>
import Spinner from '@/components/Spinner'
import Header from '@/components/Header'
import Tunes from '@/components/Tunes'
import IndexLayout from '@/components/layouts/IndexLayout'
import DetailsMovieLayout from '@/components/layouts/DetailsMovieLayout'
import DetailsTvLayout from '@/components/layouts/DetailsTvLayout'
import { mapGetters } from 'vuex'

export default {
  name: 'App',
  components: { Spinner, Header, Tunes , IndexLayout , DetailsMovieLayout, DetailsTvLayout},
  mounted(){
    window.addEventListener('resize', this.onResize)
    this.$store.dispatch('updateTranslations')
  },
  data () {
    return {
      showTunes: false,
      searchQuery: (window.localStorage.getItem('lastSearchQuery') != undefined) ? window.localStorage.getItem('lastSearchQuery') : '',
      searchTypes : [
        {key : 'movies', label : 'Кино', checked : true},
        {key : 'tv-series', label : 'Сериалы', checked : true},
        {key : 'show-tv-series', label : 'ТВ-шоу', checked : true},
      ],
      yearFilter : '',
      windowWidth : window.innerWidth,
    }
  },
  methods: {
    onResize: function(){
      this.windowWidth = window.innerWidth
      this.$store.state.isMobile = false
      if(window.innerWidth < 500 || window.innerHeight < 900){
        this.$store.state.isMobile = true
      }
    },
    scrollToTop(){
      window.scrollTo(0, 0)
    },
    search: function(event){
      if(this.searchQuery.length > 0){
        let types = []
        this.searchTypes.forEach((type) => {
          if(type.checked == true){
            types.push(type.key)
          }
        })
        if(types.length > 0){
          window.localStorage.setItem("lastSearchQuery", this.searchQuery)
          this.showTunes = false
          this.$store.commit('resetSearchResults')
          this.$store.commit('resetCurrent')
          this.$store.dispatch('search', {types: types, searchQuery: this.searchQuery, yearFilter: this.yearFilter})
        }else{
          console.log('No types')
        }
      }else{
       console.log('No query')
      }
    },
  },
  computed: {
    ...mapGetters([
      'getCurrent',
      'getSortedList'
    ])
  }
}
</script>

<style>
:root {
  --color-white: #ffffff;
  --color-blue: #2196f3;
  --color-dark: #212529;
  --color-gray: #ced4da;
  --color-lightgray: #fbfbfb;
  --color-warning: #dc3545;
}
*{
  box-sizing: border-box;
  font-family: Avenir, Helvetica, Arial, sans-serif;
  color: #2c3e50;
  margin: 0;
}
#app {
  display: flex;
  flex-direction: column;
}
.wrap{
  margin: 0 auto;
  width: 100%;
  max-width: 1320px;
}
.content{
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  border: 1px solid indigo;
}
/*[COMPONENT FADE]*/
.component-fade-enter-active,
.component-fade-leave-active {
  transition: all 0.3s ease;
}
.component-fade-enter-from,
.component-fade-leave-to {
  transform: translateX(100vw);
}
</style>